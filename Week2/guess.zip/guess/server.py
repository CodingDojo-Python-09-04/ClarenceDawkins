from flask import Flask, render_template, request, redirect, session,flash
import random

app = Flask(__name__)
app.secret_key='ThisIsSecret'

def start():
    session['num'] = random.randrange(0,101)
    
    print session['num']


@app.route('/')
def index():
    if session['num']==None:
        start()
    else:
        pass
    print session['num']  
    
    return render_template("index.html")

@app.route('/guess', methods=['POST'])
def guess():
    guess_num = int(request.form['guess'])
    if session['num'] == guess_num:
        flash('Correct')
        return redirect('/')        
    elif guess_num > session['num']:
        flash('Too High')
        return redirect('/')
    else:
        flash('Too Low')
        return redirect('/')

@app.route('/reset', methods = ['GET', 'POST'])
def reset():
    start()
    return redirect('/')

app.run(debug=True) # run our server
