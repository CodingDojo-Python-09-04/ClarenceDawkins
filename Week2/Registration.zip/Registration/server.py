from flask import Flask, render_template, request, redirect, session, flash, get_flashed_messages
import re
app = Flask(__name__)
app.secret_key='ThisIsSecret'
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
NUM_REGEX = re.compile(r'\d+')
UPPER_REGEX = re.compile(r'[A-Z]+')

@app.route('/')
def index():
  return render_template("index.html")

@app.route('/user', methods=['POST'])
def create():
    str1 = request.form['first_name']
    str2 = request.form['last_name']
    print request.form['first_name'].isalpha()
    print request.form['last_name'].isalpha()
    if len(request.form['email']) <1:
        flash("Please insert an email address ")
        return redirect('/')
    elif not EMAIL_REGEX.match(request.form['email']):
        flash("Invalid email address ")
        return redirect('/')
    elif len(request.form['first_name']) < 1:
        flash("Please enter first name ")
        return redirect('/')
    elif request.form['first_name'].isalpha() == False:
        flash("First Name must not contain numbers ")
        return redirect('/')
    elif len(request.form['last_name']) < 1:
        flash("Please enter last name ")
        return redirect('/')
    elif request.form['last_name'].isalpha() == False:
        flash("Last Name must not contain numbers ")
        return redirect('/')
    elif len(request.form['password']) < 1:
        flash("Please enter password ")
        return redirect('/')
    elif len(request.form['password']) < 8:
        flash("Please enter password more than 8 characters")
        return redirect('/')
    elif not NUM_REGEX.match(request.form['password']):
        flash("Password must contain at least 1 numeric value ")
        return redirect('/')
    # elif not UPPER_REGEX.match(request.form['password']):
    #     flash("Password must have at least 1 uppercase letter ")
    #     return redirect('/')
    elif len(request.form['confirm_password']) < 1:
        flash("Please enter confirm password ")    
        return redirect('/')   
    elif request.form['password'] != request.form['confirm_password']:
        flash("Passwords does not match. ")
        return redirect('/')  
    else:      
        session['email']=request.form['email']
        session['first_name']=request.form['first_name']
        session['last_name']=request.form['last_name']
        session['password']=request.form['password']
        session['confirm_password']=request.form['confirm_password']
        return redirect('/show')
    
    

@app.route('/show')
def show_users():
  flash("Thanks for submitting your information. ")
  return redirect('/')


app.run(debug=True) # run our server
