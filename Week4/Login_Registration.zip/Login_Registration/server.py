from flask import Flask, render_template, request, redirect, session, flash, get_flashed_messages, url_for
import re
from mysqlconnection import MySQLConnector
from flask_bcrypt import Bcrypt

app = Flask(__name__)
bcrypt = Bcrypt(app)

app.secret_key='ThisIsSecret'
mysql = MySQLConnector(app, 'varegistration')

NAME_REGEX = re.compile(r'^[a-zA-Z]+$')
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
UPPER_REGEX = re.compile(r'\d.*[A-Z]|[A-Z].*\d')
PWD_REGEX = re.compile(r'^[a-zA-Z0-9_-]$')

def get_user_id(id):
    query = "SELECT * FROM users WHERE id = :id"
    return mysql.query_db(query,{"id":id})[0] 

@app.route('/')
def index():
    flash_messages = get_flashed_messages(with_categories=True)
    staticfile = url_for('static', filename="style.css")   
    return render_template('index.html', message = flash_messages, styles=staticfile)  

@app.route('/user', methods=['POST'])
def create():
    errors = []

    first_name_match = re.match(NAME_REGEX, request.form['first_name'].strip())
    last_name_match = re.match(NAME_REGEX, request.form['last_name'].strip())
    password_match = re.match(PWD_REGEX, request.form['password'] )
    confirm_password_match = re.match(PWD_REGEX, request.form['confirm_password'] )
    
   
    if not EMAIL_REGEX.match(request.form['email']):
        errors.append("Invalid email address ")
        return redirect('/')
    if not NAME_REGEX.match(request.form['first_name']):
        errors.append("Please enter first name.  Name must not contain numbers " )
        return redirect('/')    
    if not NAME_REGEX.match(request.form['last_name']):
        errors.append("Please enter last name.  Name must not contain numbers  ")
        return redirect('/')  
    if len(request.form['first_name'])< 3:
        errors.append("Please enter a name more than 2 characters")
        return redirect('/')
    if len(request.form['last_name'])< 3:
        errors.append("Please enter a last name more than 2 characters")
        return redirect('/') 
    if len(request.form['password'])< 8:
        errors.append("Please enter password 8 characters or more")
        return redirect('/')
    # elif not PWD_REGEX.match(request.form['password']):
    #     flash("Please enter password more than 8 characters")
    #     return redirect('/')   
    if not UPPER_REGEX.match(request.form['password']):
        errors.append("Password must have at least 1 uppercase letter ")
        return redirect('/')
    # elif not PWD_REGEX.match(request.form['confirm_password']):
    #     flash("Please enter confirm password ")    
    #     return redirect('/')   
    if password_match != confirm_password_match:
        errors.append("Passwords does not match. ")
        return redirect('/') 
    
    #unique username
    query = "SELECT id from users WHERE email = :some_email"
    data = {'some_email': request.form['email']}
    #Check username
    if mysql.query_db(query,data):
        errors.append("Email already taken! ")

    #errors list
    if errors:
        for e in errors:
            flash(e,'error')
        return redirect('/')

    #Creating hash password    
    hashed = bcrypt.generate_password_hash(request.form['password'])

    #Creating the user account

    query = "INSERT INTO users (first_name, last_name, email, password, confirm_password, created_at, updated_at)\
             VALUES (:some_first_name, :some_last_name, :some_email,:some_password,:some_confirm_password,NOW(), NOW())"

    data = {
            'some_first_name': request.form['first_name'],
            'some_last_name':request.form['last_name'],  
            'some_email':request.form['email'],
            'some_password':hashed,
            'some_confirm_password':hashed           
    }        
    
    mysql.query_db(query,data) 
    flash("Successful Registration!", "success")
    return redirect('/')


#Login to account
@app.route('/login', methods=['POST'])
def login():
    errors = []

    query = "SELECT id, password FROM users WHERE email = :some_email"
    data = {'some_email': request.form['email']}
    # find user with that email/username
    user = mysql.query_db(query,data)[0]
    if not user:
        errors.append("Invalid email")
    # if username checked, verfiy password//hash
    else:
        if not bcrypt.check_password_hash(user["password"], request.form['password']):
            errors.append("Invalid password")

    if errors:
        #flash each error in list, then redirect
        for e in errors:
            flash(e,'error')
        return redirect('/')
    
    # save id to session
    session['id'] = user['id']
    flash("Successful Logged In", "success")
    return redirect('/success')  #direct to success process

@app.route('/success')
def success():
    #check session for 'id'
    try:
        session['id']
    except KeyError:
        return redirect('/')

    user = get_user_id(session['id'])
    flash_messages = get_flashed_messages(with_categories=True)

    return render_template("success.html", user = user, message = flash_messages)

#create logout process
@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect('/')


app.run(debug=True) # run our server
