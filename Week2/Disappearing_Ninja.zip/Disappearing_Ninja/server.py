from flask import Flask, render_template, request, render_template, session, flash, get_flashed_messages
import re
app = Flask(__name__)
app.secret_key='ThisIsSecret'


@app.route('/')
def index():
    flash("No Ninjas here ")
    return render_template("index.html")

@app.route('/ninja')
def process():
    return render_template('/ninjas.html')

@app.route('/ninja/blue')
def process_leo():
    return render_template('/leo.html')

@app.route('/ninja/orange')
def process_mike():
    return render_template('/mike.html')

@app.route('/ninja/red')
def process_raph():
    return render_template('/raph.html')

@app.route('/ninja/purple')
def process_don():
    return render_template('/don.html')

@app.route('/ninja/black')
def process_apr():
    return render_template('/apr.html')

@app.route('/ninja/123')
def process_apr1():
    return render_template('/apr.html')

   
# @app.route('/show')
# def show_users():
#     flash("Thanks for submitting your information. ")
#     return render_template('/')


app.run(debug=True) # run our server
