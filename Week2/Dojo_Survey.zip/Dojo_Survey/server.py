from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key='ThisIsSecret'

@app.route('/')
def index():
  return render_template("index.html")

@app.route('/user', methods=['POST'])
def create():
  print "Submitted Info"
  session['name']=request.form['name']
  session['location']=request.form['location']
  session['language']=request.form['language']
  session['comment']=request.form['comment']
  return redirect('/show')

@app.route('/show')
def show_users():
  return render_template('user.html')

app.run(debug=True) # run our server
