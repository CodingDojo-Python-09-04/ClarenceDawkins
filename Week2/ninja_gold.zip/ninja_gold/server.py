from flask import Flask, render_template, request, redirect, session,flash
import random
import time

app = Flask(__name__)
app.secret_key='ThisIsSecret'


@app.route('/')
def index():
    if 'bank' not in session:
        session['bank'] = 0    
        session['activities'] = []        
    else:
        print session['bank']

    return render_template("index.html")

@app.route('/process_money', methods=['POST'])
def process():       
    if request.form['building'] == 'farm':
        number = random.randint(10,20)        
        session['bank'] += number
        session['activities'].append("You earned " + str(number) + " golds from the farm.") # , str(time.strftime('%A %B, %d %Y %H:%M')))
        return redirect('/')        
    elif request.form['building'] == 'cave':
        number = random.randint(10,20)        
        session['bank'] += number
        session['activities'].append("You earned " + str(number) + " golds from the cave.") #str(time.strftime('%A %B, %d %Y %H:%M')))
        return redirect('/')        
    elif request.form['building'] == 'house':
        number = random.randint(10,20)        
        session['bank'] += number
        session['activities'].append("You earned " + str(number) + " golds from the house.") #str(time.strftime('%A %B, %d %Y %H:%M')))
        return redirect('/')        
    else:
        number = random.randint(10,20)        
        session['bank'] += number
        if number > 0:
            session['activities'].append("You earned " + str(number) + " golds from the casino. ") #str(time.strftime('%A %B, %d %Y %H:%M')))
        else: 
            session['activities'].append("You lost ", number , " golds from the casino." )#str(time.strftime('%A %B, %d %Y %H:%M')))
        return redirect('/')        

@app.route('/reset', methods = ['GET', 'POST'])
def reset():
    session['bank'] = []
    return redirect('/')

app.run(debug=True) # run our server
