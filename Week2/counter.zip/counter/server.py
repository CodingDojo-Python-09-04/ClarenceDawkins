from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key='ThisIsSecret'

@app.route('/')
def index():
    init = session['counter'] + 1
    session['counter'] = session['counter'] + 1
    print session['counter']
    return render_template("index.html")

@app.route('/increments')
def increments():
    session['counter'] = session['counter'] + 1
    return redirect('/')

@app.route('/reset', methods = ['GET'])
def reset():
    session['counter'] = 0
    return redirect('/')

app.run(debug=True) # run our server
