from flask import Flask, render_template, request, render_template, session, flash, get_flashed_messages, redirect
import re
# import the Connector function
from mysqlconnection import MySQLConnector
app = Flask(__name__)
# connect and store the connection in "mysql" note that you pass the database name to the function
mysql = MySQLConnector(app, 'full_friends')
# an example of running a query


@app.route('/')
def index():
    query = "SELECT * FROM friends"
    all_friends = mysql.query_db(query) 
    print all_friends
    return render_template('index.html', friends_list=all_friends)

@app.route('/friends', methods=['post'])
def create():
    query = "INSERT INTO friends (first_name, last_name, email, created_at, updated_at) \
             VALUES (:first_name,:last_name,:email, now(),now())"
    
    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email']        
    }
    mysql.query_db(query, data)
    return redirect('/')

@app.route('/friends/<id>/edit')
def edit(id):
    query = "SELECT * FROM friends WHERE id = :temp_id"
    data = {"temp_id": id}
    try:
        this_friend =  mysql.query_db(query, data)[0]
    except IndexError:
        return redirect('/')

    return render_template('edit.html', friend = this_friend)

@app.route('/friends/<id>', methods=['post'])
def update(id):
    query = "UPDATE friends \
             SET first_name = :first_name, :last_name = :last_name, email = :email \
             WHERE id= :temp_id"
    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "temp_id": id        
    }
    mysql.query_db(query, data)
    return redirect('/')

@app.route('/friends/<id>/delete', methods=['post'])
def destroy(id):
    query = "DELETE FROM friends WHERE id= :delete_id"
    data = {'delete_id':id}
    mysql.query_db(query, data)
    return redirect('/')
app.run(debug=True)